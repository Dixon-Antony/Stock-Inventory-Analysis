# Inventory Management Series With FastAPI and React

1. FastAPI Python backend
2. React Frontend

## Features:
1. Sending Emails
2. CRUD functionaity
and so much more

This project is part of a youtube series, find the video series at: [My channel](https://www.youtube.com/c/CodeWithPrince)
